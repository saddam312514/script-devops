
user_logins = [("01711091125", "12345678"),
               ("01711091126", "12345678"),
               ("01711091127", "12345678"),
               ("01711091128", "12345678"),
               ("01711091129", "12345678")]

bus_types = {"AC_B": 1, "AC_S": 2, "SNIGDHA": 3, "F_BERTH": 4, "F_SEAT": 5,
             "F_CHAIR": 6, "S_CHAIR": 7, "SHOVAN": 8, "SHULOV": 9, "AC_CHAIR": 10}

bus_types_list = ["AC_B", "AC_S", "SNIGDHA", "F_BERTH", "F_SEAT",
                  "F_CHAIR", "S_CHAIR", "SHOVAN", "SHULOV", "AC_CHAIR"]




routes = [("Dhaka","Chattogram"), ("Chattogram","Dhaka"), ("Dhaka","Rangpur"), ("Dhaka","Rajshahi"), ("Dhaka","Dinajpur"), ("Dhaka","Jashore")]

cities = ['Ahsanganj', 'Alamdanga', 'Ashuganj', 'Bajitpur', 'Banani', 'Bangabandhu Bridge East', 'BBSetu_E', 'Benapole', 'Biman Bandar', 'Biman_Bandar', 'Bogura', 'Bonar_Para', 'Bonpara', 'Boral Bridge', 'Borodorga', 'Chapai nababganj', 'Chapai Nawabganj', 'Chatmohar', 'Chattogram', 'Chuadanga', 'Court Chandpur', 'coxbazar1', 'Cumilla', 'Darsana Halt', 'Daulatpur', 'Dhaka', 'Dhaka Airport', 'Dhaka Cant', 'Dinajpur', 'DiyaBari', 'Feni', 'Gaibandha', 'Gauripur', 'Jaigirhat', 'Jaipurhat', 'Jamalpur', 'Jamtail', 'Jashore', 'Jhikorgacha', 'Joydebpur', 'Kaliganj', 'Kashba', 'Khulna', 'Kishorganj', 'Kolkata', 'Kuliarchar', 'Laksham', 'mao"wa ', 'Mawna', 'Mirpur', 'Mobarakgonj', 'Narsingdi', 'Natore', 'New Jalpaiguri', 'Parbatipur', 'Poradaha', 'Rajshahi', 'Rangpur', 'raowa', 'S M MD Ali', 'SH M Monsur Ali', 'Shamshernagar', 'Sirajganj', 'Tangail', 'test parent 2', 'Thakurgaon', 'Ullapara']

